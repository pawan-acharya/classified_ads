<footer class="py-5">
    <div class="container">
        @include('layouts.admin.footers.nav')
    </div>
</footer>