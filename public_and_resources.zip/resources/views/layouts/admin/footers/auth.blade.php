<footer class="footer">
    @include('layouts.admin.footers.nav')
</footer>