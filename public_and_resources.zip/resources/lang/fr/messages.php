<?php

return [
    'reset_password_subject' => 'Réinitialiser la notification de mot de passe',
    'reset_password_main_line' => 'Vous recevez cet e-mail, car nous avons reçu une demande de réinitialisation du mot de passe pour votre compte.',
    'reset_password' =>  'réinitialiser le mot de passe',
    'reset_password_expire_link' => 'Ce lien de réinitialisation de mot de passe expirera dans :count les minutes.',
    'reset_password_more_info' => 'Si vous n’avez pas demandé de réinitialisation du mot de passe, aucune autre action n’est requise.'
];